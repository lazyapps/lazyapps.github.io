# Shheep — プレスキット

- 製品サイト: [https://lazyapps.com/shheep/ja/](https://lazyapps.com/shheep/ja/)
- プレスキット: [https://lazyapps.com/shheep/presskit/#ja](https://lazyapps.com/shheep/presskit/#ja)
- 対応環境: iPhone · iPad
- 提供状況: App Store で公開中
- メディアお問い合わせ: [lazyapps.feedback@gmail.com](mailto:lazyapps.feedback@gmail.com)

## アプリについて

iPhone・iPad で遊ぶ羊のジャンプゲーム

柵を跳び越え、コウモリを避けて羊を数えよう。毎晩新しいコースに挑戦。Shheep は iPhone・iPad で配信中。

柵を一つ跳び越えると、羊が一匹増えます。長く押すと、少し高くジャンプ。コウモリが来たらかがんでよけよう。低く飛んでいたら跳び越えても大丈夫。

夜ごとに新しいコースが登場。同じ柵とコウモリに再挑戦して、もっと羊を数えよう。連続プレイの記録も残ります。日付が変わっても、お昼までは同じ夜です。

障害物に当たると終了。再挑戦するか、数えた羊の数をおやすみカードにして共有できます。

iPhone・iPad アプリは Game Center のランキング、友達へのチャレンジや招待に対応。

ウェブデモの記録はこのブラウザだけに保存され、アプリとは同期されません。

## 公式リンク

- [App Store](https://apps.apple.com/app/id6819031865)
- [ウェブデモを試す](https://lazyapps.com/shheep/)

## 画像素材

### アプリアイコン

[icon.png](../icon.png)

1024 × 1024 · PNG

原版の App アイコン。1024 × 1024 PNG。図柄・比率・透明部分を保持。

### ワードマーク

[wordmark.png](../wordmark.png)

163 × 61 · PNG

元の透過ピクセルワードマーク。輪郭と縦横比を保持してください。

### スクリーンショット

[bedroom-preview.png](../bedroom-preview.png)

1050 × 560 · PNG

共通のゲームタイトル画面プレビュー。プレイ中の画面ではありません。

### デスクトップ背景

[website-background.png](../website-background.png)

1536 × 1024 · PNG

ウェブサイトでの展示用にAIで生成した装飾背景です。アプリのスクリーンショット、ゲーム内の場面、内蔵機能ではありません。

### ワードマーク

[wordmark.svg](../wordmark.svg)

163.0 × 61.0 · SVG

元のピクセルワードマークを可逆変換したSVGです。各ピクセルの形、色、透明度を保持し、平滑化やビットマップの埋め込みは行っていません。

### SNS共有画像

[social-card.png](../social-card.png)

1200 × 630 · PNG

宣伝用画像であり、アプリ画面のスクリーンショットではありません。

## 素材の使用について

本製品を紹介する報道にご利用ください。名称、比率、製品の文脈を保持し、lazyapps のクレジットと製品サイトへのリンクを掲載してください。第三者のコンテンツや商標の権利は各権利者に帰属し、このキットはそれらの単独利用を許諾しません。他の用途はお問い合わせください。
