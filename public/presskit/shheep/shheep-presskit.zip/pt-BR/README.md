# Shheep — Kit de imprensa

- Site do produto: [https://lazyapps.com/shheep/pt-br/](https://lazyapps.com/shheep/pt-br/)
- Kit de imprensa: [https://lazyapps.com/shheep/presskit/#pt-BR](https://lazyapps.com/shheep/presskit/#pt-BR)
- Plataforma: iPhone · iPad
- Disponibilidade: Disponível na App Store
- Contato de imprensa: [lazyapps.feedback@gmail.com](mailto:lazyapps.feedback@gmail.com)

## Sobre o app

Conte ovelhas no iPhone e iPad

Pule cercas, desvie de morcegos e conte ovelhas em um percurso novo a cada noite. Shheep já está disponível para iPhone e iPad.

Pule uma cerca e ela conta mais uma ovelha. Segure um pouco mais para pular mais alto. Quando vier um morcego, abaixe-se ou pule por cima se ele voar baixo.

Um percurso novo a cada noite. Volte às mesmas cercas e morcegos, tente contar mais ovelhas e mantenha sua sequência. Passou da meia-noite? Até o meio-dia ainda é a mesma noite.

Bater em um obstáculo encerra a partida. Recomece ou compartilhe um cartão de boa noite com a quantidade de ovelhas que contou.

O app para iPhone e iPad oferece placares do Game Center, desafios e convites para amigos.

Os recordes da demo web ficam neste navegador e não são sincronizados com o app.

## Links oficiais

- [App Store](https://apps.apple.com/app/id6819031865)
- [Experimentar a demo web](https://lazyapps.com/shheep/)

## Imagens

### Ícone do app

[icon.png](../icon.png)

1024 × 1024 · PNG

Ícone nativo original, PNG 1024 × 1024. Arte, proporções e transparência preservadas.

### Logotipo

[wordmark.png](../wordmark.png)

163 × 61 · PNG

Logotipo original em pixels com transparência; preserve bordas e proporções.

### Captura de tela

[bedroom-preview.png](../bedroom-preview.png)

1050 × 560 · PNG

Prévia compartilhada da tela de título do jogo, não de uma partida em andamento.

### Plano de fundo da área de trabalho

[website-background.png](../website-background.png)

1536 × 1024 · PNG

Fundo decorativo gerado por IA para apresentação no site; não é uma captura do app, uma cena do jogo nem um recurso integrado.

### Imagem para redes sociais

[social-card.png](../social-card.png)

1200 × 630 · PNG

Imagem promocional, não uma captura do app.

## Uso dos materiais

Para publicações sobre este produto. Preserve nomes, proporções e contexto; dê crédito à lazyapps e inclua o site do produto. Conteúdos e marcas de terceiros mantêm seus direitos; este kit não autoriza reutilização separada. Entre em contato para outros usos.
