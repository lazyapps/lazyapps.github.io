# Shheep — Kit stampa

- Sito del prodotto: [https://lazyapps.com/shheep/it/](https://lazyapps.com/shheep/it/)
- Kit stampa: [https://lazyapps.com/shheep/presskit/#it](https://lazyapps.com/shheep/presskit/#it)
- Piattaforma: iPhone · iPad
- Disponibilità: Disponibile sull’App Store
- Contatto stampa: [lazyapps.feedback@gmail.com](mailto:lazyapps.feedback@gmail.com)

## Informazioni sull’app

Conta le pecore su iPhone e iPad

Salta le staccionate, evita i pipistrelli e conta le pecore su un nuovo percorso ogni notte. Shheep è disponibile per iPhone e iPad.

Salta una staccionata e lei conta una pecora in più. Tieni premuto un po’ più a lungo per saltare più in alto. Quando arriva un pipistrello, abbassati o saltalo se vola basso.

Un nuovo percorso ogni notte. Torna alle stesse staccionate e agli stessi pipistrelli, prova a contare più pecore e continua la tua serie. È passata mezzanotte? Fino a mezzogiorno è ancora la stessa notte.

Un ostacolo termina la partita. Ricomincia o condividi un biglietto della buonanotte con il numero di pecore contate.

L’app per iPhone e iPad offre classifiche Game Center, sfide e inviti agli amici.

I record della demo web restano in questo browser e non si sincronizzano con l’app.

## Link ufficiali

- [App Store](https://apps.apple.com/app/id6819031865)
- [Prova la demo web](https://lazyapps.com/shheep/)

## Immagini

### Icona dell’app

[icon.png](../icon.png)

1024 × 1024 · PNG

Icona nativa originale, PNG 1024 × 1024. Grafica, proporzioni e trasparenza preservate.

### Logotipo

[wordmark.png](../wordmark.png)

163 × 61 · PNG

Logotipo originale in pixel con trasparenza; conserva bordi e proporzioni.

### Schermata

[bedroom-preview.png](../bedroom-preview.png)

1050 × 560 · PNG

Anteprima condivisa della schermata del titolo del gioco, non di una partita in corso.

### Sfondo decorativo

[website-background.png](../website-background.png)

1536 × 1024 · PNG

Sfondo decorativo generato con IA per la presentazione sul sito; non è una schermata dell’app, una scena di gioco o una funzione integrata.

### Logotipo

[wordmark.svg](../wordmark.svg)

163.0 × 61.0 · SVG

SVG senza perdita del logotipo pixel originale. Forme, colori e trasparenza di ogni pixel sono preservati, senza smussatura né bitmap incorporata.

### Immagine per i social

[social-card.png](../social-card.png)

1200 × 630 · PNG

Immagine promozionale, non una schermata dell’app.

## Uso dei materiali

Per articoli dedicati a questo prodotto. Mantieni nomi, proporzioni e contesto; cita lazyapps e collega il sito del prodotto. I contenuti e i marchi di terzi conservano i rispettivi diritti; questo kit non ne autorizza il riutilizzo separato. Contattaci per altri usi.
