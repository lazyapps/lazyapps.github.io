# Shheep — Press Kit

- Website: [https://lazyapps.com/shheep/](https://lazyapps.com/shheep/)
- Press Kit: [https://lazyapps.com/shheep/presskit/#en](https://lazyapps.com/shheep/presskit/#en)
- Platform: iPhone · iPad
- Availability: Available on the App Store
- Media contact: [lazyapps.feedback@gmail.com](mailto:lazyapps.feedback@gmail.com)

## About the app

Count sheep on iPhone & iPad

Jump over fences, duck under bats and count sheep on a new course each night. Shheep is available on iPhone and iPad.

Hop over a fence and she counts one more sheep. Hold a little longer to jump a little higher. When a bat flies by, duck down—or hop over it if it’s low.

A new course for every night. Come back for the same fences and bats, try to count a few more, and keep your nightly streak going. Past midnight? It’s still the same night until noon.

Hit an obstacle and the run ends. Start again or share a good-night card showing the number of sheep you counted.

The iPhone and iPad app supports Game Center leaderboards, friend challenges and invitations.

Web demo scores stay in this browser and do not sync with the app.

## Official links

- [App Store](https://apps.apple.com/app/id6819031865)
- [Try the web demo](https://lazyapps.com/shheep/)

## Images

### App icon

[icon.png](../icon.png)

1024 × 1024 · PNG

Original native App icon, 1024 × 1024 PNG. Preserves the app’s artwork, proportions and transparency.

### Wordmark

[wordmark.png](../wordmark.png)

163 × 61 · PNG

Original transparent pixel wordmark from the exported game assets. Preserve pixel edges and aspect ratio; this is a wordmark, not an app icon.

### Screenshot

[bedroom-preview.png](../bedroom-preview.png)

1050 × 560 · PNG

Existing game title-screen preview (1050 × 560), not an active gameplay screenshot.

### Desktop wallpaper

[website-background.png](../website-background.png)

1536 × 1024 · PNG

AI-generated pixel night-sky backdrop for the website presentation; not a game screenshot or built-in game scene.

### Wordmark

[wordmark.svg](../wordmark.svg)

163.0 × 61.0 · SVG

Lossless SVG of the original pixel wordmark. Exact pixel shapes, colors and transparency are preserved without smoothing or an embedded bitmap.

### Social sharing image

[social-card.png](../social-card.png)

1200 × 630 · PNG

Existing 1200 × 630 promotional artwork, not an app screenshot.

## Using these materials

For editorial coverage of this product. Preserve names, proportions and context; credit lazyapps and link to the product website. Third-party content and trademarks retain their respective rights; this kit grants no standalone reuse rights. Contact us for other uses.
