# Calmon — 媒體資料

- 產品網站: [https://lazyapps.com/calmon/zh-Hant/](https://lazyapps.com/calmon/zh-Hant/)
- 媒體資料頁: [https://lazyapps.com/calmon/presskit/#zh-Hant](https://lazyapps.com/calmon/presskit/#zh-Hant)
- 平台: macOS 26 或更新版本
- 發佈狀態: Beta 期間免費
- 媒體聯絡: [lazyapps.feedback@gmail.com](mailto:lazyapps.feedback@gmail.com)

## 產品簡介

Calmon 將 Mac 視窗排成可滾動的列。支持同應用堆疊、固定列和桌面切換。滑鼠或鍵盤都能操作。

macOS 26 或更新版本

多顯示器建議上下排列。橫向並排時，共享邊緣會阻斷滾動，切換列時會循環跳轉。兩側都有顯示器時，後台視窗會疊在當前視窗後方。

Beta 期間免費

遇到問題或有想法，來 X 找 @lazyapps。謝謝你幫 Calmon 變得更好用。

視窗橫向排列，隨焦點滾動。當前列佔據大部分螢幕。在前導鍵模式中用方向鍵切換。

一欄可分成最多三個上下排列的區域，同時顯示多個視窗。每個區域可放一個視窗，也可放一組 App 堆疊。

同一 App 的平鋪視窗預設重疊在同一區域，一次顯示一個。點擊視窗頂部的堆疊標記，或按 ⌘` 切換。

前導鍵模式: Space → J / X — 將目前視窗加入／移出同 App 堆疊。

將一列固定在左側或右側，其他視窗在旁邊滾動。在前導鍵模式中按 Tab 切換焦點。

最多固定十個 App，各顯示器共用順序。點擊 Pin Deck 標記添加 App。通過圖標選單移出 App。

Sky Deck 顯示浮動視窗，Max Deck 顯示原生全屏視窗。點擊圖標返回對應視窗。

點擊桌面編號切換桌面。在前導鍵模式中按圖標標籤選擇視窗。按 Shift 和 1–9 將視窗移到其他桌面。

點擊分頁列圖標選擇視窗。按住 Control 點擊圖示，打開視窗選單。點擊佈局圖打開按鍵面板。點擊面板上的按鍵執行操作。

不想自動顯示面板，可在「設定 → 鍵盤 → 按鍵面板 → 延遲顯示」中選擇「永不」。點擊佈局圖仍會立即打開。

雙擊並放開 ⌘ 進入前導鍵模式。視窗有反白外框時，可連續執行命令。按 Esc 退出。

, / . — 獨佔一欄時，併入左／右相鄰欄；同欄有多個區域時，將目前區域拆成左／右獨立欄。區域中的整組堆疊會一起移動。

Space → J / X — 將目前視窗加入／移出同 App 堆疊

macOS 26: 輔助使用; macOS 27+: 裝置控制和資料取用

需要輔助使用權限，用於移動視窗、調整大小和切換焦點。

不用。滑鼠可完成全部視窗操作。點擊佈局圖可隨時打開按鍵面板。

輕掃預設關閉。可在「設定 → 手勢」中啟用三指或四指輕掃。輕掃前按住 Shift，可使用原有的 macOS 手勢。 請在「系統設定」>「觸控式軌跡板」>「更多手勢」中保持三指或四指手勢開啟。

標準視窗預設平鋪。對話框、設定視窗和固定大小的視窗預設浮動。可在「設定 → 進階」中按 App 或標題添加規則。

只有主動移動時，視窗才會改變所屬桌面。可用桌面編號或前導鍵模式切換桌面。退出 Calmon 時會恢復保存的視窗位置。

是的，Beta 期間免費。

在 Calmon 選單中選擇「檢查更新…」。

[X @lazyapps](https://x.com/lazyapps)

## 官方連結

- [免費下載](https://github.com/cxa/calmon/releases)

## 圖片素材

### App 圖示

[icon.png](../icon.png)

1024 × 1024 · PNG

原版 App 圖示，1024 × 1024 PNG。保留原版圖案、比例與透明邊角。

### App 圖示 · icon-dark.png

[icon-dark.png](../icon-dark.png)

1024 × 1024 · PNG

原版 App 圖示，1024 × 1024 PNG。保留原版圖案、比例與透明邊角。

### 選單列圖示 · menubar-2x.png

[menubar-2x.png](../menubar-2x.png)

44 × 44 · PNG

選單列圖示 · PNG · 44 × 44 · 2×

### 按鍵面板

[leader-keys.png](leader-keys.png)

1196 × 780 · PNG

對應語言的原生介面預覽，像素保持原樣。

### 平面向量圖

[lettering-flat.svg](../lettering-flat.svg)

684.0 × 684.0 · SVG

由原版向量圖案和圖層位置組合的平面 SVG，不重現原生玻璃、光照或系統圖示裁切。完整原生 App 圖示請使用 PNG。

### 社群分享圖

[social-card.png](../social-card.png)

1200 × 630 · PNG

宣傳圖片，不是 App 介面截圖。

## 使用說明

這些素材用於介紹本產品的媒體報導。請保留名稱、比例與產品語境，署名 lazyapps 並連結產品網站。第三方內容與商標保留各自權利；本資料包不授予其獨立使用權。如需其他用途，請聯絡我們。
